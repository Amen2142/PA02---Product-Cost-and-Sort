import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class CostAnalysis
{
	static double[] product1 = new double[4];
	static double[] product2 = new double[4];
	static double[] sums = new double[4];
	static String[] names = new String[] {"Website & Search Engine Marketing", "Social Media Marketing", "Radio Advertising", "Newspaper Advertising"};
	
	public static void main(String[] args)
	{
		int tryAgain = JOptionPane.YES_OPTION;
		while(tryAgain == 0)
		{
			try
			{
				product1[0] = Double.parseDouble(JOptionPane.showInputDialog(
						  "Please enter the Website & Search Engine Marketing costs for the first product."));
				product1[1] = Double.parseDouble(JOptionPane.showInputDialog(
						  "Please enter the Social Media Marketing costs for the first product."));
				product1[2] = Double.parseDouble(JOptionPane.showInputDialog(
						  "Please enter the Radio Advertising costs for the first product."));
				product1[3] = Double.parseDouble(JOptionPane.showInputDialog(
						  "Please enter the Newspaper Advertising costs for the first product."));
				
				product2[0] = Double.parseDouble(JOptionPane.showInputDialog(
						  "Please enter the Website & Search Engine Marketing costs for the second product."));
				product2[1] = Double.parseDouble(JOptionPane.showInputDialog(
						  "Please enter the Social Media Marketing costs for the second product."));
				product2[2] = Double.parseDouble(JOptionPane.showInputDialog(
						  "Please enter the Radio Advertising costs for the second product."));
				product2[3] = Double.parseDouble(JOptionPane.showInputDialog(
						  "Please enter the Newspaper Advertising costs for the second product."));
				
				display();
				
				if (product1[0] < 0 || product1[1] < 0 || product1[2] < 0 || product1[3] < 0 || product2[0] < 0 || product2[1] < 0 || product2[2] < 0 || product2[3] < 0)
					throw new Exception();
				
				break;
				
			} catch(Exception e)
			{
				JOptionPane.showMessageDialog(null, "Invalid input! Please try again.");
			} // End try/catch
			System.exit(0);
			
		} // End while
	} // End main
	
	public static double totalCostPerProduct(double[] productCosts)
	{
		double sum = productCosts[0] + productCosts[1] + productCosts[2] + productCosts[3];
		return sum;
	}
	
	public static double[] totalCostPerExpenditure(double[] product1, double[] product2)
	{
		double[] sum = new double[4];
		sum[0] = product1[0] + product2[0];
		sum[1] = product1[1] + product2[1];
		sum[2] = product1[2] + product2[2];
		sum[3] = product1[3] + product2[3];
		
		return sum;
	}
	
	public static int highestCostCalculator(double[] highestCost)
	{
		int maximum = 0;
		for (int i = 0; i < 3; i++)
			if (highestCost[i+1] > highestCost[maximum])
				maximum = i+1;
		
		return maximum;
	}
	
	public static int lowestCostCalculator(double[] lowestCost)
	{
		int minimum = 0;
		for (int i = 0; i < 3; i++)
			if (lowestCost[i+1] < lowestCost[minimum])
				minimum = i+1;
		
		return minimum;
	}
	
	public static double percentageCalculator(double[] array1, double[] array2, int num)
	{
		double largest = 0;
		double total = 0;
		double division = 0;
		
		if (array1[num] > array2[num])
			largest = array1[num];
		else if (array1[num] < array2[num])
			largest = array2[num];
		else
			largest = array1[num];
			
		total = array1[num] + array2[num];
			
		division = (largest / total) * 100;
		
		return division;
	}
	
	public static void display()
	{
		sums = totalCostPerExpenditure(product1, product2);
		
		String out = "Expenditure Item Name" + "\t" + "Product-1" + "\t" + "Product-2" + "\t" + "Total cost for each expenditure item" + "\n\n" + 
                "Website & Search Engine" + "\t" + product1[0] + "\t" + product2[0] + "\t" + sums[0] + "(" + percentageCalculator(product1, product2, 0) + "%" + ")" + "\n\n" + 
                "Social Media"            + "\t\t" + product1[1] + "\t" + product2[1] + "\t" + sums[1] + "(" + percentageCalculator(product1, product2, 1) + "%" + ")" + "\n\n" +
                "Radio Advertising"       + "\t" + product1[2] + "\t" + product2[2] + "\t" + sums[2] + "(" + percentageCalculator(product1, product2, 2) + "%" + ")" + "\n\n" +
                "Newspaper Advertising"   + "\t" + product1[3] + "\t" + product2[3] + "\t" + sums[3] + "(" + percentageCalculator(product1, product2, 3) + "%" + ")" + "\n\n" +
                "Total cost per product"  + "\t" + totalCostPerProduct(product1) + "\t" + totalCostPerProduct(product2) + "\t" + (totalCostPerProduct(product1) + totalCostPerProduct(product2));
		
		JOptionPane.showMessageDialog(null, new JTextArea(out));
		
		out = "\t\t" + "Product-1" + "\t\t\t" + "Product-2" + "\t\t\t\t" + "Product-1 & Product-2 Combined" + "\n\n" + 
                "Highest Expenditure Item" + "\t" + names[highestCostCalculator(product1)] + "\t\t" + names[highestCostCalculator(product2)] + "\t\t\t" + names[highestCostCalculator(sums)] + "\n\n" + 
                "Lowest Expenditure Item"  + "\t" + names[lowestCostCalculator(product1)] + "\t\t" + names[lowestCostCalculator(product2)] + "\t\t\t" + names[lowestCostCalculator(sums)];
		
		
		JOptionPane.showMessageDialog(null, new JTextArea(out));                           
	}
	
} // End class