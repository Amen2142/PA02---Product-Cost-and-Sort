package Q2;

public class Sort 
{
	public static void selectionSort(String[] pName, double[] pPrice)
	{
		for (int i = 0; i < pPrice.length - 1; i++) 
		{
			
		      double currentMin = pPrice[i];
		      String currentMinInfo = pName[i];
		      int currentMinIndex = i;
		      

		      for (int j = i + 1; j < pPrice.length; j++) 
		      {
		        if (currentMin > pPrice[j]) 
		        {
		          currentMin = pPrice[j];
		          currentMinInfo = pName[j];
		          currentMinIndex = j;
		        }
		      } // End inner for 

		      if (currentMinIndex != i) 
		      {
		    	  // swap for billArr 
		    	  pPrice[currentMinIndex] = pPrice[i];
		    	  pPrice[i] = currentMin;
		    	  
		    	  // swap for infoArr
		    	  pName[currentMinIndex] = pName[i];
		    	  pName[i] = currentMinInfo;
		    	  
		      } // End if
		} // End outer for
	}
}
