package Q2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Product 
{
	public static void main(String[] args) throws FileNotFoundException
	{
		String[] pName = new String[50];
		double[] pPrice = new double[50];
		readFromFile(pName, pPrice, "products.txt");
		
		sortArrays(pName, pPrice);
		
		writeToFile(pName, pPrice);
	} // End main
	
	// Read data from file
	public static void readFromFile(String[] pName, double[] pPrice, String filename) throws FileNotFoundException
	{
		File file = new File(filename);
		
	    // Create a Scanner for the file
	    Scanner sc = new Scanner(file);

	    sc.useDelimiter(",|\r\n");
	    
	    // Start reading data from file using while loop
	    int i = 0;
	    while (sc.hasNext())
	    {
	    	String productName = sc.next();
	    	double price = Double.parseDouble(sc.next().trim());
	    	
	    	pName[i] = productName + "";
	    	pPrice[i] = price;
	    	
	    	i++;
	    }
		
	    sc.close();
	    
	    // Concatenate elements of arrays into a string
	    String output = "";
	    for(int j = 0; j < 50; j++) 
			output += pName[j] + ": " + String.format("%.1f", pPrice[j]) + "\n";
	    
	    // Display string in a JOptionPane dialogue box
	    JOptionPane.showMessageDialog(null, output, "Products and Prices:", JOptionPane.INFORMATION_MESSAGE);
		
	} // End readFromFile
	
	// Sort both arrays based on prices in pPrice array
	public static void sortArrays(String[] pName, double[] pPrice)
	{
		Sort.selectionSort(pName, pPrice);
	} // End sortArrays
	
	// Write and store sorted array elements 
	public static void writeToFile(String[] pName, double[] pPrice) throws FileNotFoundException
	{
				String fileName = "sortedPrices.txt";
				
			    File file = new File(fileName);
			    
			    PrintWriter printer = new PrintWriter(file);
		        
			    // Concatenate array elements into string
			    String output = "";
				for(int i = 0; i < pPrice.length; i++) 
							output += pName[i] + ": " + String.format("%.1f", pPrice[i]) + "\n";
				
				// Print contents of string into text file
				printer.print(output);
			    
			    printer.close();
			    
			    JOptionPane.showMessageDialog(null, "Completed Writing Data to File \"sortedPrices.txt\"");
	} // End writeToFile
	
} // End class
